# Automation sample - Scan Completed event (Java / JUnit 5)

Self-contained and offline. Needs JDK 17+ and Maven 3.8+. No real endpoints, credentials or customer data.
The only dependency is JUnit 5 (HTTP via `java.net.http`, mock via `com.sun.net.httpserver`).

```bash
mvn test                                  # healthy run: all 4 tests pass
MOCK_FAULT=drop_ios_mkt_b mvn test        # reproduces the incident: iOS + MKT_B fails
MOCK_FAULT=duplicate mvn test             # duplicate-event detection
```

Real test environment: set `APP_API_BASE`, `DEST_API_BASE`, `API_TOKEN` (from the CI secret store) and optionally
`EVENT_SLA_SECONDS`. The same tests then run against it instead of the mock.

| File | Purpose |
|---|---|
| `pom.xml` | Maven project (Java 17, JUnit 5) |
| `src/test/java/qa/ScanEventContractTest.java` | API contract + asynchronous downstream assertions |
| `src/test/java/qa/mock/MockServices.java` | Illustrative backend scan API + CDP/destination API, with fault injection |
| `src/test/java/qa/util/MiniJson.java` | Tiny JSON helper (a real framework would use Jackson/Gson) |
